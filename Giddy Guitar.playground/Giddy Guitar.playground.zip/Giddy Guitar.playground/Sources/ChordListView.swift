import UIKit

class ChordListView: UIView {
	private var stackView: UIStackView!
	
	var chordTappedHandler: ((Chord) -> ())?
	
	init() {
		super.init(frame: CGRect.zero)
		
		commonInit()
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
		
		commonInit()
	}
	
	private func commonInit() {
		initAndConstrainStackView()
		
		addChordViews()
		
		addTapRecognizer()
	}
	
	private func initAndConstrainStackView() {
		stackView = UIStackView()
		stackView.axis = .horizontal
		stackView.spacing = 15
		
		stackView.translatesAutoresizingMaskIntoConstraints = false
		addSubview(stackView)
		
		stackView.topAnchor.constraint(equalTo: topAnchor).isActive = true
		stackView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
		stackView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
		stackView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
	}
	
	private func addChordViews() {
		stackView.addArrangedSubview(ChordLemonView(chord: Chord.c))
		stackView.addArrangedSubview(ChordLemonView(chord: Chord.g))
		stackView.addArrangedSubview(ChordLemonView(chord: Chord.d))
		stackView.addArrangedSubview(ChordLemonView(chord: Chord.em))
		stackView.addArrangedSubview(ChordLemonView(chord: Chord.am))
	}
	
	func frameOfChordView(withChord chord: Chord, inView view: UIView) -> CGRect? {
		for ChordLemonView in stackView.arrangedSubviews {
			if (ChordLemonView as! ChordLemonView).chord.name == chord.name {
				return view.convert(ChordLemonView.frame, from: self)
			}
		}
		
		return nil
	}
	
	private func addTapRecognizer() {
		let recognizer = UILongPressGestureRecognizer(target: self, action: #selector(tapped(recognizer:)))
		recognizer.minimumPressDuration = 0
		
		addGestureRecognizer(recognizer)
	}
	
	func tapped(recognizer: UILongPressGestureRecognizer) {
		guard recognizer.state == .began else {
			return
		}
		
		for view in stackView.arrangedSubviews {
			if view.frame.contains(recognizer.location(in: self)) {
				let lemonView = view as! ChordLemonView
				lemonView.doSqueezeAnimation()
				chordTappedHandler?(lemonView.chord)
			}
		}
	}
	
	func squeezeAnimatedLemon(withChord chord: Chord) {
		for view in stackView.arrangedSubviews {
			let lemonView = view as! ChordLemonView
			if lemonView.chord.name == chord.name {
				lemonView.doSqueezeAnimation()
			}
		}
	}
}
