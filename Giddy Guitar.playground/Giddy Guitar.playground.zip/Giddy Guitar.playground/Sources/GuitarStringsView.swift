import UIKit

class GuitarStringsView: UIView {
	private let defaultStringsColor: UIColor = UIColor(red: 220.0/255, green: 150.0/255, blue: 100.0/255, alpha: 1)
	
	private var stringLayers: [CALayer] = []
	
	init() {
		super.init(frame: CGRect.zero)
		
		backgroundColor = UIColor.clear
		
		initStringLayers()
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
	
	override func layoutSubviews() {
		super.layoutSubviews()
		
		adjustStringLayerDimensions()
	}
	
	private func initStringLayers() {
		for _ in 0..<6 {
			let strLayer = CALayer()
			strLayer.backgroundColor = defaultStringsColor.cgColor
			
			layer.addSublayer(strLayer)
			
			stringLayers.append(strLayer)
		}
	}
	
	private func adjustStringLayerDimensions() {
		let lineWidth: CGFloat = 2
		
		for i in 0..<stringLayers.count {
			let stringYCoor: CGFloat = round((bounds.height - lineWidth) / 5 * CGFloat(i))
			stringLayers[i].frame = CGRect(x: 0, y: stringYCoor, width: bounds.width, height: lineWidth)
		}
	}
	
	func pickStringAnimated(at index: Int, withColor color: UIColor) {	//Index starts at zero from the top-most string (high E string)
		let stringLayer = stringLayers[index]
		
		stringLayer.removeAllAnimations()
		
		stringLayer.opacity = 0.4
		stringLayer.bounds.size.height = 6
		stringLayer.backgroundColor = color.cgColor
		
		let duration: CFTimeInterval = 1.5
		
		let vibrationFrameChange = CABasicAnimation(keyPath: "bounds.size.height")
		vibrationFrameChange.fromValue = 6
		vibrationFrameChange.toValue = 2
		
		let vibrationOpacityChange = CABasicAnimation(keyPath: "opacity")
		vibrationOpacityChange.fromValue = 0.4
		vibrationOpacityChange.toValue = 1
		
		stringLayer.bounds.size.height = 2
		stringLayer.opacity = 1
		stringLayer.backgroundColor = color.cgColor
		
		let group = CAAnimationGroup()
		group.animations = [vibrationFrameChange, vibrationOpacityChange]
		group.duration = duration
		
		stringLayer.add(group, forKey: "pickAnimation")
	}
}
