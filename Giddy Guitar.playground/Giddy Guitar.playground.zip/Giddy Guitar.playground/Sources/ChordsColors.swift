import UIKit

class ChordsColors {
	class func colorFor(_ chordName: String) -> UIColor? {
		switch chordName {
			case "C":
			return colorForC()
			case "G":
			return colorForG()
			case "D":
			return colorForD()
			case "Em":
			return colorForEm()
			case "Am":
			return colorForAm()
		default:
			return nil
		}
	}
	
	class func colorForC() -> UIColor {
		return UIColor(red: 1, green: 85.0/255, blue: 200.0/255, alpha: 1)
	}
	
	class func colorForG() -> UIColor {
		return UIColor(red: 105.0/255, green: 205.0/255, blue: 5.0/255, alpha: 1)
	}
	
	class func colorForD() -> UIColor {
		return UIColor(red: 1, green: 160.0/255, blue: 0, alpha: 1)
	}
	
	class func colorForEm() -> UIColor {
		return UIColor(red: 0, green: 185.0/255, blue: 1, alpha: 1)
	}
	
	class func colorForAm() -> UIColor {
		return UIColor(red: 240.0/255, green: 220.0/255, blue: 0, alpha: 1)
	}
}
