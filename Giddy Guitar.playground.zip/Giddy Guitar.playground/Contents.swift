//: Welcome to Giddy Guitar
//: -----------------------
//: This playground presents a guitar that you can strum by clicking on the lemon slices at the bottom.
//: Click the "Play a Song!" button on top to sit back and watch the computer play "Yellow Submarine" by The Beatles with chords!
//:
//: The song is composed by the author of this playground in Garageband, using the acoustic guitar, flute, bass and drums. The ocean waves
//: sound effect is "Waves at Baltic Sea shore" by pulswell at Freesound.org ([link](https://www.freesound.org/s/339517/)), provided under the Creative Commons license.
import PlaygroundSupport
import UIKit

let viewController = GuitarViewController()
viewController.view.frame = CGRect(x: 0, y: 0, width: 700, height: 500)

//: To run properly on iPad, please change value of "`runningOnIpad`" flag below to `true`.
var runningOnIpad = false
if runningOnIpad {
    PlaygroundPage.current.liveView = viewController
} else {
    PlaygroundPage.current.liveView = viewController.view
}

PlaygroundPage.current.needsIndefiniteExecution = true

//:
//: The song is composed by the author of this playground in Garageband, using the acoustic guitar, flute, bass and drums. The ocean waves
//: sound effect is "Waves at Baltic Sea shore" by pulswell at Freesound.org ([link](https://www.freesound.org/s/339517/)), provided under the Creative Commons license.
//:
//: Hope you enjoy it!
