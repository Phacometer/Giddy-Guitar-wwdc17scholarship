import Foundation
import UIKit

struct Chord {
	let name: String
	let duration: Int
	let color: UIColor
	
	init(name: String, duration: Int) {
		self.name = name
		self.duration = duration
		self.color = ChordsColors.colorFor(name)!
	}
	
	static var c: Chord {
		return Chord(name: "C", duration: 0)
	}
	
	static var g: Chord {
		return Chord(name: "G", duration: 0)
	}
	
	static var d: Chord {
		return Chord(name: "D", duration: 0)
	}
	
	static var em: Chord {
		return Chord(name: "Em", duration: 0)
	}
	
	static var am: Chord {
		return Chord(name: "Am", duration: 0)
	}
}
