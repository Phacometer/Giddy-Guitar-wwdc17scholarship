import AVFoundation

class ChordSoundPlayer {
	var audioPlayers: [String: AVAudioPlayer] = [:]
	
	init() {
		audioPlayers[Chord.am.name] = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "am chord",
		                                                                             withExtension: "mp3",
		                                                                             subdirectory: "chord sounds")!)
		audioPlayers[Chord.c.name] = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "c chord",
		                                                                            withExtension: "mp3",
		                                                                            subdirectory: "chord sounds")!)
		audioPlayers[Chord.d.name] = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "d chord",
		                                                                            withExtension: "mp3",
		                                                                            subdirectory: "chord sounds")!)
		audioPlayers[Chord.em.name] = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "em chord",
		                                                                             withExtension: "mp3",
		                                                                             subdirectory: "chord sounds")!)
		audioPlayers[Chord.g.name] = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "g chord",
		                                                                            withExtension: "mp3",
		                                                                            subdirectory: "chord sounds")!)
		
		for player in audioPlayers.values {
			player.volume = 0.3
			player.prepareToPlay()
		}
	}
	
	func play(chord: Chord) {
		audioPlayers[chord.name]?.stop()
		audioPlayers[chord.name]?.currentTime = 0
		audioPlayers[chord.name]?.play()
	}
}
