import UIKit
import AVFoundation
import PlaygroundSupport
import SpriteKit

public class GuitarViewController: UIViewController {
	
	private var backgroundView: BackgroundView!
	private var guitarImageView: UIImageView!
	private var stringsView: GuitarStringsView!
	private var playButton: UIButton!
	private var chordListView: ChordListView!
	private var chorusAnimationView: ChorusSceneView!
	private var thanksForWatchingLabel: UILabel!
	
	private var chordsTimer: ChordsTimer = ChordsTimer()
	
	private var chordSoundPlayer: ChordSoundPlayer!
	private var songPlayer: AVAudioPlayer!
	
	public init() {
		super.init(nibName: nil, bundle: nil)
	}
	
	required public init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
	
	public override func viewDidLoad() {
		super.viewDidLoad()
		
		initAndConstrainBackgroundView()
		initAndConstrainGuitarImageView()
		initChorusAnimationView()
		initAndConstrainPlayButton()
		initAndConstrainChordListView()
		initAndConstrainStringsView()
		initThanksForWatchingLabel()
		
		chordSoundPlayer = ChordSoundPlayer()
		
		chordsTimer.loadChords()
	}
	
	private func initChorusAnimationView() {
		chorusAnimationView = ChorusSceneView(frame: view.bounds)
		chorusAnimationView.translatesAutoresizingMaskIntoConstraints = false
		view.addSubview(chorusAnimationView)
		chorusAnimationView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
		chorusAnimationView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
		chorusAnimationView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
		chorusAnimationView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
		print(chorusAnimationView.frame)
	}
	
	private func initAndConstrainBackgroundView() {
		backgroundView = BackgroundView()
		backgroundView.translatesAutoresizingMaskIntoConstraints = false
		
		view.addSubview(backgroundView)
		
		backgroundView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
		backgroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
		backgroundView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
		backgroundView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
	}
	
	private func initAndConstrainGuitarImageView() {
		guitarImageView = UIImageView(image: UIImage(named: "images/guitar"))
		guitarImageView.contentMode = .center
		
		guitarImageView.translatesAutoresizingMaskIntoConstraints = false
		view.insertSubview(guitarImageView, aboveSubview: backgroundView)
		
		guitarImageView.heightAnchor.constraint(equalTo: view.heightAnchor).isActive = true
		guitarImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -30).isActive = true
		guitarImageView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
		guitarImageView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
	}
	
	private func initAndConstrainStringsView() {
		stringsView = GuitarStringsView()
		
		stringsView.translatesAutoresizingMaskIntoConstraints = false
		view.addSubview(stringsView)

		stringsView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
		stringsView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
		stringsView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -30).isActive = true
		stringsView.heightAnchor.constraint(equalToConstant: 60).isActive = true
	}
	
	private func initAndConstrainPlayButton() {
		playButton = UIButton(type: .system)
		playButton.setBackgroundImage(UIImage(named: "images/play button"), for: .normal)
		playButton.addTarget(self, action: #selector(startGame), for: .touchUpInside)
		playButton.translatesAutoresizingMaskIntoConstraints = false
		
		view.addSubview(playButton)
		
		playButton.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
		playButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
	}
	
	private func initAndConstrainChordListView() {
		chordListView = ChordListView()
		chordListView.chordTappedHandler = chordTapped
		
		chordListView.translatesAutoresizingMaskIntoConstraints = false
		view.addSubview(chordListView)
		
		chordListView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10).isActive = true
		chordListView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
	}
	
	private func initThanksForWatchingLabel() {
		thanksForWatchingLabel = UILabel()
		thanksForWatchingLabel.text = "Thank you for watching!"
		thanksForWatchingLabel.textColor = UIColor.black
		thanksForWatchingLabel.font = UIFont(name: "AmericanTypewriter-Bold", size: 21)
		thanksForWatchingLabel.alpha = 0
	}
	
	func startGame() {
		startPlayingSong()
		
		backgroundView.animateWaves()
		
		chordsTimer.startTimer(withCallback: { (chord) in
			self.triggerChord(chord)
			self.chordListView.squeezeAnimatedLemon(withChord: chord)
		}, completion: {
			self.showThankYouMessage()
		}, chorusStartCallback: {
			self.chorusAnimationView.startAnimation()
		})
	}
	
	private func startPlayingSong() {
		if songPlayer == nil {
			songPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "yellow submarine", withExtension: "mp3")!)
		}
		
		songPlayer.stop()
		songPlayer.currentTime = 0
		songPlayer.prepareToPlay()
		songPlayer.play()
		
		UIView.animate(withDuration: 0.5, animations: {
			self.playButton.alpha = 0
		})
	}
	
	private func showThankYouMessage() {
		DispatchQueue.main.async {
			self.thanksForWatchingLabel.translatesAutoresizingMaskIntoConstraints = false
			self.view.addSubview(self.thanksForWatchingLabel)
		
			self.thanksForWatchingLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor, constant: 0).isActive = true
			self.thanksForWatchingLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 20).isActive = true
			
			UIView.animate(withDuration: 0.5, animations: {
				self.thanksForWatchingLabel.alpha = 1
			})
		}
	}
	
	func chordTapped(chord: Chord) {
		triggerChord(chord)
		
		if !thanksForWatchingLabel.isHidden {
			thanksForWatchingLabel.textColor = chord.color
		}
	}
	
	private func triggerChord(_ chord: Chord) {
		launchProjectile(fromLemonWithChord: chord)
		strum(chord: chord)
	}
	
	private func launchProjectile(fromLemonWithChord chord: Chord) {
		let frame = chordListView.frameOfChordView(withChord: chord, inView: view)!
		let insetFrame = frame.insetBy(dx: frame.width / 3, dy: frame.height / 3)
		let projectile = UIView(frame: insetFrame)
		projectile.layer.cornerRadius = min(projectile.frame.width, projectile.frame.height) / 2
		projectile.backgroundColor = chord.color
		projectile.alpha = 0.8
		
		view.insertSubview(projectile, belowSubview: chordListView)
		UIView.animate(withDuration: 0.3, animations: {
			projectile.frame.origin = CGPoint(x: projectile.frame.origin.x, y: -projectile.frame.height)
		}, completion: { _ in
			projectile.removeFromSuperview()
		})
	}
	
	private func strum(chord: Chord) {
		chordSoundPlayer.play(chord: chord)
		
		(0..<6).reversed().forEach { index in
			let deadline = DispatchTime.now() + Double(5-index) * 0.02
			DispatchQueue.main.asyncAfter(deadline: deadline, execute: {
				self.stringsView.pickStringAnimated(at: index, withColor: chord.color)
			})
		}
	}
}
