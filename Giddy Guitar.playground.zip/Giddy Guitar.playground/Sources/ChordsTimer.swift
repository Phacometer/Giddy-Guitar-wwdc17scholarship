import Foundation
import QuartzCore

class ChordsTimer {	//Timer that keeps track of when a chord in a song should be played
	private(set) var beatsPerMin: Int = 0
	private(set) var beatsBeforeFirstChord: Int = 0	//Sometimes in a song the first chord is played not on the first beat
	//but after several beats. This property stores the beat at which
	//the first chord is played.
	private(set) var beatsBeforeChorus: Int = 0
	private(set) var chords: [Chord] = []
	
	var timer: CADisplayLink! = nil
	var nextChordTimestamp: Date!
	
	private var timerCallback: ((Chord) -> ())?
	private var completionCallback: (() -> ())?
	private var chorusStartCallback: (() -> ())?
	private var currentChordIndex: Int = 0
	
	init() {
		timer = CADisplayLink(target: self, selector: #selector(triggerChord))
		timer.preferredFramesPerSecond = 60
	}
	
	func loadChords() {
		let chordsData = try! Data(contentsOf: Bundle.main.url(forResource: "song", withExtension: "json")!)
		
		let chordsJsonObject = try? JSONSerialization.jsonObject(with: chordsData, options: [])
		if let jsonDict = chordsJsonObject as? [String: Any] {
			beatsPerMin = jsonDict["beatsPerMin"] as! Int
			beatsBeforeFirstChord = jsonDict["beatsBeforeFirstChord"] as! Int
			beatsBeforeChorus = jsonDict["beatsBeforeChorus"] as! Int
			let chords = jsonDict["chords"] as! [[String: Any]]
			processChordsInArray(chords)
		}
	}
	
	private func processChordsInArray(_ chordsArray: [[String: Any]]) {
		for chordObject in chordsArray {
			let name = chordObject["name"] as! String
			let duration = chordObject["duration"] as! Int
			chords.append(Chord(name: name, duration: duration))
		}
	}
	
	func startTimer(withCallback callback: @escaping (Chord) -> (), completion: @escaping () -> (), chorusStartCallback: @escaping () -> ()) {
		timerCallback = callback
		completionCallback = completion
		self.chorusStartCallback = chorusStartCallback
		
		DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + beatsToSeconds(beatsBeforeChorus), execute: {
			self.chorusStartCallback?()
		})
		
		nextChordTimestamp = Date().addingTimeInterval(beatsToSeconds(beatsBeforeFirstChord))
		timer.add(to: .current, forMode: .commonModes)
	}
	
	@objc func triggerChord() {
		if Date().timeIntervalSince(nextChordTimestamp) >= 0 {
			let currentChord = self.chords[self.currentChordIndex]
			timerCallback?(currentChord)
			
			if reachedLastChord() {
				completionCallback?()
				resetTimerVariables()
			} else {
				currentChordIndex += 1
				nextChordTimestamp.addTimeInterval(beatsToSeconds(currentChord.duration))
				print(beatsToSeconds(currentChord.duration))
			}
		}
	}
	
	private func reachedLastChord() -> Bool {
		return currentChordIndex == (chords.count - 1)
	}
	
	private func resetTimerVariables() {
		timerCallback = nil
		completionCallback = nil
		currentChordIndex = 0
		timer.invalidate()
	}
	
	private func beatsToSeconds(_ beats: Int) -> TimeInterval {
		return Double(beats) * (60 / Double(beatsPerMin))
	}
}
