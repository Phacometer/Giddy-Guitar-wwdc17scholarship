import UIKit

class ChorusSceneView: UIView {
	private var submarineImageView: UIImageView!
	private var constraint: NSLayoutConstraint!

	override init(frame: CGRect) {
		super.init(frame: frame)
		
		submarineImageView = UIImageView()
		submarineImageView.contentMode = .center
		
		var frames = [UIImage]()
		for i in 1...5 {
			let imageName = "submarine animation/submarine\(i)"
			frames.append(UIImage(named: imageName)!)
		}
		
		submarineImageView.animationImages = frames
		submarineImageView.animationDuration = 1
		submarineImageView.animationRepeatCount = 0
		submarineImageView.translatesAutoresizingMaskIntoConstraints = false
		
		addSubview(submarineImageView)
		
		constraint = submarineImageView.leftAnchor.constraint(equalTo: rightAnchor)
		constraint.isActive = true
		submarineImageView.topAnchor.constraint(equalTo: centerYAnchor, constant: 60).isActive = true
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
	
	func startAnimation() {
		submarineImageView.startAnimating()
		UIView.animate(withDuration: 25, delay: 0, options: .curveLinear, animations: {
			self.constraint.constant = -(self.frame.width + self.submarineImageView.frame.width)
			self.layoutIfNeeded()
		}, completion: { _ in
			self.submarineImageView.stopAnimating()
			self.constraint.isActive = false
			self.submarineImageView.rightAnchor.constraint(equalTo: self.leftAnchor, constant: 0).isActive = true
		})
	}
}
