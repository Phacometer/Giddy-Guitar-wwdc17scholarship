import UIKit

class BackgroundView: UIView {
	var frontWaveImageView: UIImageView!
	var backWaveImageView: UIImageView!
	var frontLeftConstraint: NSLayoutConstraint!
	var backLeftConstraint: NSLayoutConstraint!
	
	init() {
		super.init(frame: CGRect.zero)
		
		frontWaveImageView = UIImageView(image: UIImage(named: "images/sea")!)
		frontWaveImageView.contentMode = .topLeft
		frontWaveImageView.translatesAutoresizingMaskIntoConstraints = false
		addSubview(frontWaveImageView)
		
		frontWaveImageView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: 0).isActive = true
		frontLeftConstraint = frontWaveImageView.leftAnchor.constraint(equalTo: leftAnchor, constant: -50)
		frontLeftConstraint.isActive = true
		frontWaveImageView.rightAnchor.constraint(equalTo: rightAnchor, constant: 0).isActive = true
		frontWaveImageView.topAnchor.constraint(equalTo: centerYAnchor, constant: 65).isActive = true
		
		backWaveImageView = UIImageView(image: UIImage(named: "images/sea2")!)
		backWaveImageView.contentMode = .topLeft
		backWaveImageView.translatesAutoresizingMaskIntoConstraints = false
		insertSubview(backWaveImageView, belowSubview: frontWaveImageView)
		
		backWaveImageView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: 0).isActive = true
		backLeftConstraint = backWaveImageView.leftAnchor.constraint(equalTo: leftAnchor, constant: -50)
		backLeftConstraint.isActive = true
		backWaveImageView.rightAnchor.constraint(equalTo: rightAnchor, constant: 0).isActive = true
		backWaveImageView.topAnchor.constraint(equalTo: centerYAnchor, constant: 65).isActive = true
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
	}
	
	override func draw(_ rect: CGRect) {
		super.draw(rect)

		drawGradientBackground()
	}
	
	private func drawGradientBackground() {
		let context = UIGraphicsGetCurrentContext()
		let colors = [UIColor.white.cgColor, UIColor(white: 0.9, alpha: 1).cgColor] as CFArray
		let backgroundGradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1])
		let center = CGPoint(x: bounds.midX, y: bounds.midY)
		context?.drawRadialGradient(backgroundGradient!,
		                            startCenter: center,
		                            startRadius: 20,
		                            endCenter: center,
		                            endRadius: min(bounds.width, bounds.height),
		                            options: [.drawsAfterEndLocation, .drawsBeforeStartLocation])
	}
	
	func animateWaves() {
		UIView.animate(withDuration: 2, delay: 0, options: [.autoreverse, .repeat, .curveEaseInOut], animations: {
			self.frontLeftConstraint.constant = 0
			self.backLeftConstraint.constant = -100
			self.layoutIfNeeded()
		}, completion: nil)
	}
}
