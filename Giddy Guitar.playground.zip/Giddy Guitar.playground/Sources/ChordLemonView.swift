import UIKit

class ChordLemonView: UIView {
	var chord: Chord!
	
	private var lemonImageView: UIImageView!
	private var chordNameLabel: UILabel!
	
	init(chord: Chord) {
		self.chord = chord
		
		super.init(frame: CGRect.zero)
		
		initAndConstrainControls()
		
		setControls(with: chord)
	}
	
	private func setControls(with chord: Chord) {
		let imageFileName = "images/" + chord.name + " lemon"
		lemonImageView.image = UIImage(named: imageFileName)
		
		chordNameLabel.text = chord.name
		chordNameLabel.textColor = chord.color
	}
	
	func doSqueezeAnimation() {
		UIView.animateKeyframes(withDuration: 0.5, delay: 0, options: [], animations: {
			UIView.addKeyframe(withRelativeStartTime: 0, relativeDuration: 1/20, animations: {
				self.lemonImageView.transform = CGAffineTransform(scaleX: 0.6, y: 1.2)
			})
			UIView.addKeyframe(withRelativeStartTime: 1/20, relativeDuration: 19/20, animations: {
				self.lemonImageView.transform = CGAffineTransform.identity
			})
		}, completion: nil)
	}
	
	required init?(coder aDecoder: NSCoder) {
		super.init(coder: aDecoder)
		
		initAndConstrainControls()
	}
	
	private func initAndConstrainControls() {
		initAndConstrainLemonImageView()
		initAndConstrainChordNameLabel()
	}
	
	private func initAndConstrainLemonImageView() {
		lemonImageView = UIImageView()
		lemonImageView.contentMode = .center
		
		lemonImageView.translatesAutoresizingMaskIntoConstraints = false
		addSubview(lemonImageView)
		
		lemonImageView.topAnchor.constraint(equalTo: topAnchor).isActive = true
		lemonImageView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
		lemonImageView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
	}
	
	private func initAndConstrainChordNameLabel() {
		chordNameLabel = UILabel()
		chordNameLabel.font = UIFont(name: "AmericanTypewriter-Bold", size: 18)
		
		chordNameLabel.translatesAutoresizingMaskIntoConstraints = false
		addSubview(chordNameLabel)
		
		chordNameLabel.topAnchor.constraint(equalTo: lemonImageView.bottomAnchor, constant: 2).isActive = true
		chordNameLabel.centerXAnchor.constraint(equalTo: centerXAnchor).isActive = true
		chordNameLabel.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
	}
}
